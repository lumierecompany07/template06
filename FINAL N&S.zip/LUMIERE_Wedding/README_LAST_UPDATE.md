# LUMIÈRE – Updated Pixar-inspired wedding guest attire

Open `index.html` with the `assets/` folder intact. The new separate Gentlemen and Ladies illustrations replace only Dress Code character art; existing 4 admin-selected dress colours, guest colour swatches, 70% looping music, no-countdown 15 s intro and other site functions are retained.

Assets updated:
- `assets/images/guest-gents-pixar.png`
- `assets/images/guest-ladies-pixar.png`
- `assets/images/guest-gents-pixar-mask.png`
- `assets/images/guest-ladies-pixar-mask.png`

The mask images identify the outfit regions so only the suit and dress receive the selected colour; skin, faces, hair and accessories remain unchanged. If deployed, upload the updated index and all updated image assets together.
