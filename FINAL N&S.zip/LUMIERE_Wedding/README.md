# LUMIÈRE Wedding Invitation – Complete Website Package

## ආරම්භ කරන්නේ මෙහෙමයි
1. ZIP එක සම්පූර්ණයෙන් extract කරන්න.
2. Extract කළ folder එකේ `index.html` browser එකෙන් open කරන්න.
3. `assets/` folder එක `index.html` එකට සමීපව තියාගන්න. Video සහ music ඒ folder එක තුළ තියෙනවා.
4. Website එක publish කරන විට `index.html` + `assets/` දෙකම hosting service එකට upload කරන්න.

## Included features
- 15-second vertical beach-car wedding intro MP4, optional opening gate, sky names reveal, no 3-2-1 countdown, smooth main invitation transition.
- "A Garden Promise" piano background music (about 2:56), configured around 70% volume and to loop.
- Rich rose-gold floral backgrounds and title decorations.
- Pixar-inspired male/female wedding *guest* outfit illustrations with colour masks.
- Dress Code: four customisable swatches; tapping any swatch previews that colour on both outfits.
- Memory Card: greeting, photo upload, guest messages/"Love Letter" display.
- RSVP, invitation details, guest details, contact and other pre-existing website sections.
- Preview pages and images in `PREVIEWS/`.

## වැදගත් – Customize / Save / Guest Links
- Customize section එකේ Save කරපු වෙනස්කම් **එම browser/device එකේ localStorage** තුළ තියෙන්න පුළුවන්. ඒ private browser data එක මේ ZIP එකට automatically add වෙන්නේ නැහැ.
- `index.html` එකක් අලුතින් download කරන එකෙන් කලින් Save කළ personal edits වෙනත් device එකකින් ලැබෙන්නේ නැහැ.
- Guest link එක අලුත් data සමඟ create/copy කරලා share කරන්න; previously sent links update වෙන්නේ නැහැ. එකම published URL එක live update කිරීමට hosted database/publishing workflow අවශ්‍යයි.
- Real guest responses shared across devices වෙන්න නම් functional backend hosting/database එකක් අවශ්‍ය විය හැකියි. Static local HTML file එකක් shared cloud database එකක් නෙවෙයි.

## Original code and assets
- `index.html` – latest site source.
- `assets/video/couple-scooter-intro.mp4` – latest provided INTRO video (15s).
- `assets/music/A_Garden_Promise.mp3` – looping music (about 2:56).
- `assets/images/guest-*-pixar.png` – updated guest outfit illustrations.
- `assets/images/guest-*-pixar-mask.png` – outfit-only recolouring masks.
- `assets/images/*background*` – existing invitation backgrounds.
- `PREVIEWS/` – preview screenshots for easy reference.

## Known pre-existing optional image references
The existing HTML references a few image paths that were not present in the last supplied website archive. They were not invented or silently substituted in this package:
- `assets/images/hero-couple-photo.webp`
- `assets/images/memory-photo.webp`
- `assets/images/ring-floral-ornament.webp`
- `assets/images/section-decoration.webp`

To use custom hero/memory photos, upload them in the relevant Customize settings and share/publish the resulting site as appropriate. This package preserves the latest known project assets without replacing any image with an unrelated one.
